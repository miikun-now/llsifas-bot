# Setup
pip install requests  
pip install pycrypto

# Info
ラブライブ！スクールアイドルフェスティバルALL STARS  
https://itunes.apple.com/jp/app/id1377018522  
https://play.google.com/store/apps/details?id=com.klab.lovelive.allstars